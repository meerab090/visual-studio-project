
using System;
using System.Data;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace CandidateApp
{
    public partial class CandidateForm : Form
    {
        string conStr = @"DATA SOURCE=localhost:1521/xe;USER ID=MYXE;PASSWORD=System090";

        public CandidateForm()
        {
            InitializeComponent();
        }

        private void CandidateForm_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            using (OracleConnection con = new OracleConnection(conStr))
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO CANDIDATES (NAME, CNIC, PARTY, ADDRESS) VALUES (:name, :cnic, :party, :address)";
                    OracleCommand cmd = new OracleCommand(query, con);
                    cmd.Parameters.Add("name", txtName.Text);
                    cmd.Parameters.Add("cnic", txtCNIC.Text);
                    cmd.Parameters.Add("party", txtParty.Text);
                    cmd.Parameters.Add("address", txtAddress.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Candidate saved successfully.");
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void LoadData()
        {
            using (OracleConnection con = new OracleConnection(conStr))
            {
                try
                {
                    con.Open();
                    OracleDataAdapter da = new OracleDataAdapter("SELECT * FROM CANDIDATES", con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Load Error: " + ex.Message);
                }
            }
        }
    }
}
