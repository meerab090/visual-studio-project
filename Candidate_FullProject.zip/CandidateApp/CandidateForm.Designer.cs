
namespace CandidateApp
{
    partial class CandidateForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtCNIC;
        private System.Windows.Forms.TextBox txtParty;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView dataGridView1;

        private void InitializeComponent()
        {
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtCNIC = new System.Windows.Forms.TextBox();
            this.txtParty = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();

            // txtName
            this.txtName.Location = new System.Drawing.Point(12, 12);
            this.txtName.Name = "txtName";
            this.txtName.PlaceholderText = "Name";
            this.txtName.Size = new System.Drawing.Size(200, 23);

            // txtCNIC
            this.txtCNIC.Location = new System.Drawing.Point(12, 41);
            this.txtCNIC.Name = "txtCNIC";
            this.txtCNIC.PlaceholderText = "CNIC";
            this.txtCNIC.Size = new System.Drawing.Size(200, 23);

            // txtParty
            this.txtParty.Location = new System.Drawing.Point(12, 70);
            this.txtParty.Name = "txtParty";
            this.txtParty.PlaceholderText = "Party";
            this.txtParty.Size = new System.Drawing.Size(200, 23);

            // txtAddress
            this.txtAddress.Location = new System.Drawing.Point(12, 99);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.PlaceholderText = "Address";
            this.txtAddress.Size = new System.Drawing.Size(200, 23);

            // btnSave
            this.btnSave.Location = new System.Drawing.Point(12, 128);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(200, 30);
            this.btnSave.Text = "Save Candidate";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            // dataGridView1
            this.dataGridView1.Location = new System.Drawing.Point(12, 170);
            this.dataGridView1.Size = new System.Drawing.Size(500, 200);

            // CandidateForm
            this.ClientSize = new System.Drawing.Size(530, 400);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtCNIC);
            this.Controls.Add(this.txtParty);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dataGridView1);
            this.Name = "CandidateForm";
            this.Text = "Candidate Details";
            this.Load += new System.EventHandler(this.CandidateForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
